"""
NexGenX Windows Agent Tray App
===============================
System tray application for the NexGenX Windows Agent.
Shows access code, server status, and provides quick config.

Requirements: pystray, Pillow, win32gui/win32con (pywin32)

On first run: generates access code, displays it in a notification,
saves it to C:\\ProgramData\\NexGenX\\agent_access.txt

Then starts the agent_server.py in a background thread.
"""

import io
import os
import subprocess
import sys
import threading
import time
import tempfile
import hashlib
import secrets
import socket
from pathlib import Path
from functools import wraps

# ─── Access code setup ────────────────────────────────────────────────────────
ACCESS_CODE_FILE = Path(os.environ.get("PROGRAMDATA", "C:/ProgramData")) / "NexGenX" / "agent_access.txt"
ACCESS_CODE_HASH_FILE = Path(os.environ.get("PROGRAMDATA", "C:/ProgramData")) / "NexGenX" / "agent_access_hash.txt"
SERVER_PORT = 9400


def generate_access_code() -> str:
    return secrets.token_hex(8)


def save_access_code(code: str):
    ACCESS_CODE_FILE.parent.mkdir(parents=True, exist_ok=True)
    ACCESS_CODE_HASH_FILE.parent.mkdir(parents=True, exist_ok=True)
    ACCESS_CODE_FILE.write_text(code)
    ACCESS_CODE_HASH_FILE.write_text(hashlib.sha256(code.encode()).hexdigest())
    try:
        os.chmod(str(ACCESS_CODE_FILE), 0o600)
        os.chmod(str(ACCESS_CODE_HASH_FILE), 0o600)
    except Exception:
        pass


def load_or_create_access_code() -> str:
    if ACCESS_CODE_FILE.exists() and ACCESS_CODE_HASH_FILE.exists():
        return ACCESS_CODE_FILE.read_text().strip()
    code = generate_access_code()
    save_access_code(code)
    return code


# ─── Icon image (Pillow generates a simple icon) ──────────────────────────────
def make_icon_image() -> bytes:
    """Create a simple 64x64 icon showing 'NX' logo in blue/white."""
    from PIL import Image, ImageDraw, ImageFont
    img = Image.new("RGBA", (64, 64), (30, 60, 120, 255))
    draw = ImageDraw.Draw(img)
    # Draw a circle background
    draw.ellipse([4, 4, 60, 60], fill=(30, 90, 200, 255))
    # Draw 'NX' text
    try:
        font = ImageFont.truetype("arial.ttf", 22)
    except Exception:
        font = ImageFont.load_default()
    draw.text((10, 14), "NX", fill=(255, 255, 255, 255), font=font)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


# ─── Server process management ────────────────────────────────────────────────
_server_process = None
_server_thread = None


def start_server_thread(port: int = SERVER_PORT):
    """Start FastAPI server in background thread."""
    global _server_process
    import uvicorn
    from agent_server import app

    def run():
        uvicorn.run(app, host="0.0.0.0", port=port, log_level="warning",
                    access_log=False, lifespan="off")

    _server_thread = threading.Thread(target=run, daemon=True)
    _server_thread.start()
    time.sleep(1)
    return _server_thread is not None


def is_server_running() -> bool:
    """Check if the FastAPI server is responding."""
    import requests
    try:
        r = requests.get(f"http://127.0.0.1:{SERVER_PORT}/ping", timeout=2)
        return r.status_code == 200
    except Exception:
        return False


def get_server_ip() -> str:
    try:
        return socket.gethostbyname(socket.gethostname())
    except Exception:
        return "127.0.0.1"


# ─── System tray setup ───────────────────────────────────────────────────────
def show_notification(title: str, message: str):
    """Show a Windows toast notification."""
    try:
        import win32gui
        import win32con
        # Try using Windows 10+ toast via winrt, fallback to old balloon
        try:
            from winrt.windows.ui.notifications import ToastNotificationManager, ToastNotification
            from winrt.windows.data.xml.dom import XmlDocument
            # Simpler: just use winsound beep + tray tooltip update
            pass
        except ImportError:
            pass

        # Fallback: use PowerShell for toast
        ps = f'''
        [Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null
        $template = [Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent([Windows.UI.Notifications.ToastTemplateType]::ToastText02)
        $textNodes = $template.GetElementsByTagName("text")
        $textNodes.Item(0).AppendChild($template.CreateTextNode("{title}")) | Out-Null
        $textNodes.Item(1).AppendChild($template.CreateTextNode("{message}")) | Out-Null
        $toast = [Windows.UI.Notifications.ToastNotification]::new($template)
        [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier("NexGenX Agent").Show($toast)
        '''
        subprocess.run(["powershell", "-Command", ps],
                       capture_output=True, creationflags=0x08000000)
    except Exception:
        pass  # Notification failures are non-fatal


def run_tray():
    """Main tray app entry point."""
    global _server_process

    # ── Generate/show access code ──
    access_code = load_or_create_access_code()
    server_ip = get_server_ip()

    # Show notification with access code (first run)
    show_notification(
        "NexGenX Agent Started",
        f"Access code: {access_code}\nServer: http://{server_ip}:{SERVER_PORT}"
    )

    # ── Start the server ──
    start_server_thread()
    time.sleep(1)

    # ── Build tray icon from PIL image ──
    icon_bytes = make_icon_image()

    import pystray
    from PIL import Image

    icon_image = Image.open(io.BytesIO(icon_bytes))

    menu_status = f"Running on port {SERVER_PORT}"
    menu_ip = f"Server IP: {server_ip}"

    def copy_code():
        try:
            import pyperclip
            pyperclip.copy(access_code)
        except ImportError:
            import subprocess
            subprocess.run(["cmd", "/c", f"echo {access_code}|clip"], capture_output=True)

    def make_menu():
        return pystray.Menu(
            pystray.MenuItem("NexGenX Windows Agent", None, enabled=False),
            pystray.MenuItem(menu_status, None, enabled=False),
            pystray.MenuItem(menu_ip, None, enabled=False),
            pystray.MenuItem(f"Access Code: {access_code}", None, enabled=False),
            pystray.MenuItem("───", None, enabled=False),
            pystray.MenuItem("Copy Access Code", lambda: copy_code()),
            pystray.MenuItem("Show Access Code", lambda: show_notification("Access Code", access_code)),
            pystray.MenuItem("Server Status", lambda: show_notification(
                "Server Status",
                "Running" if is_server_running() else "Stopped"
            )),
            pystray.MenuItem("Restart Server", lambda: (start_server_thread(), show_notification("NexGenX", "Server restarted"))),
            pystray.MenuItem("───", None, enabled=False),
            pystray.MenuItem("Open in Browser (noVNC)", lambda: subprocess.Popen(
                ["cmd", "/c", f"start http://127.0.0.1:6080/vnc.html"], shell=False
            )),
            pystray.MenuItem("───", None, enabled=False),
            pystray.MenuItem("Exit", lambda: sys.exit(0)),
        )

    icon = pystray.Icon("NexGenX Agent", icon_image,
                         "NexGenX Windows Agent", make_menu())

    # Update tooltip with status
    icon.title = f"NexGenX Agent | Code: {access_code[:8]} | Running"

    def update_menu_items():
        """Periodically refresh menu items to show current status."""
        while True:
            time.sleep(30)
            if icon:
                icon.menu = make_menu()

    updater = threading.Thread(target=update_menu_items, daemon=True)
    updater.start()

    icon.run()


if __name__ == "__main__":
    print("Starting NexGenX Windows Agent Tray App...")
    print("NOTE: This window will close. The agent runs in the system tray.")
    print("Look for the NexGenX icon in your system tray (bottom-right).")
    time.sleep(2)

    try:
        run_tray()
    except Exception as e:
        print(f"Tray app error: {e}")
        print("Starting in headless server-only mode...")
        import uvicorn
        from agent_server import app
        uvicorn.run(app, host="0.0.0.0", port=SERVER_PORT, log_level="info",
                    access_log=False, lifespan="off")
